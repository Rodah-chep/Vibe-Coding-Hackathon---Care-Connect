
DROP INDEX idx_doctor_availability_doctor_id;
DROP INDEX idx_health_resources_category;
DROP INDEX idx_wellness_insights_date;
DROP INDEX idx_wellness_insights_user_id;
DROP INDEX idx_appointments_date;
DROP INDEX idx_appointments_doctor_id;
DROP INDEX idx_appointments_patient_id;
DROP INDEX idx_user_profiles_role;
DROP INDEX idx_user_profiles_user_id;
DROP TABLE doctor_availability;
DROP TABLE health_resources;
DROP TABLE wellness_insights;
DROP TABLE appointments;
DROP TABLE user_profiles;
