
-- Remove all dummy data in reverse order
DELETE FROM doctor_availability WHERE doctor_id IN ('doc_001', 'doc_002', 'doc_003', 'doc_004', 'doc_005');
DELETE FROM health_resources WHERE author IN ('Dr. Sarah Johnson', 'Dr. Lisa Williams', 'Nutritionist Jane Adams', 'Personal Trainer Mike Stevens', 'Dr. Michael Chen', 'Sleep Specialist Dr. Robert Park', 'Dr. David Thompson', 'Dietitian Sarah Martinez');
DELETE FROM wellness_insights WHERE user_id IN ('patient_001', 'patient_002', 'patient_003', 'patient_004', 'patient_005', 'patient_006');
DELETE FROM appointments WHERE patient_id IN ('patient_001', 'patient_002', 'patient_003', 'patient_004', 'patient_005', 'patient_006');
DELETE FROM user_profiles WHERE user_id IN ('doc_001', 'doc_002', 'doc_003', 'doc_004', 'doc_005', 'patient_001', 'patient_002', 'patient_003', 'patient_004', 'patient_005', 'patient_006');
