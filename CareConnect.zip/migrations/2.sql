
-- Insert sample doctor profiles
INSERT INTO user_profiles (user_id, role, first_name, last_name, phone, date_of_birth, gender, medical_license_number, specialization, bio, years_experience, hourly_rate, profile_image_url) VALUES
('doc_001', 'doctor', 'Sarah', 'Johnson', '+1-555-0101', '1985-03-15', 'female', 'MD12345', 'Cardiology', 'Experienced cardiologist specializing in preventive heart care and cardiac rehabilitation. Passionate about helping patients maintain heart health through lifestyle changes.', 12, 200.00, 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=400'),
('doc_002', 'doctor', 'Michael', 'Chen', '+1-555-0102', '1982-07-22', 'male', 'MD23456', 'Dermatology', 'Board-certified dermatologist with expertise in skin cancer prevention, cosmetic dermatology, and treating complex skin conditions.', 15, 180.00, 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=400'),
('doc_003', 'doctor', 'Emily', 'Rodriguez', '+1-555-0103', '1988-11-08', 'female', 'MD34567', 'Pediatrics', 'Dedicated pediatrician committed to providing comprehensive care for children from infancy through adolescence. Specializes in childhood development and immunizations.', 8, 160.00, 'https://images.unsplash.com/photo-1594824388875-3ba861ea4b50?w=400'),
('doc_004', 'doctor', 'David', 'Thompson', '+1-555-0104', '1975-09-30', 'male', 'MD45678', 'Orthopedics', 'Orthopedic surgeon with over 20 years of experience in joint replacement, sports medicine, and trauma surgery. Former team physician for professional athletes.', 20, 250.00, 'https://images.unsplash.com/photo-1582750433449-648ed127bb54?w=400'),
('doc_005', 'doctor', 'Lisa', 'Williams', '+1-555-0105', '1990-01-12', 'female', 'MD56789', 'Mental Health', 'Licensed psychiatrist specializing in anxiety, depression, and cognitive behavioral therapy. Advocates for mental health awareness and holistic treatment approaches.', 6, 170.00, 'https://images.unsplash.com/photo-1594824388875-3ba861ea4b50?w=400');

-- Insert sample patient profiles
INSERT INTO user_profiles (user_id, role, first_name, last_name, phone, date_of_birth, gender) VALUES
('patient_001', 'patient', 'John', 'Smith', '+1-555-0201', '1995-06-18', 'male'),
('patient_002', 'patient', 'Maria', 'Garcia', '+1-555-0202', '1987-12-03', 'female'),
('patient_003', 'patient', 'Robert', 'Davis', '+1-555-0203', '1972-04-25', 'male'),
('patient_004', 'patient', 'Jennifer', 'Brown', '+1-555-0204', '1993-08-14', 'female'),
('patient_005', 'patient', 'William', 'Wilson', '+1-555-0205', '1985-10-07', 'male'),
('patient_006', 'patient', 'Ashley', 'Taylor', '+1-555-0206', '1991-02-28', 'female');

-- Insert sample appointments
INSERT INTO appointments (patient_id, doctor_id, appointment_date, duration_minutes, status, reason, notes) VALUES
('patient_001', 'doc_001', '2025-09-05 10:00:00', 30, 'scheduled', 'Annual cardiac checkup', 'Patient reports occasional chest tightness during exercise'),
('patient_002', 'doc_002', '2025-09-03 14:30:00', 45, 'scheduled', 'Skin cancer screening', 'Family history of melanoma'),
('patient_003', 'doc_004', '2025-09-04 09:15:00', 60, 'scheduled', 'Knee pain consultation', 'Chronic knee pain after old sports injury'),
('patient_004', 'doc_005', '2025-09-06 11:00:00', 50, 'scheduled', 'Anxiety management', 'Follow-up on anxiety treatment plan'),
('patient_005', 'doc_003', '2025-09-02 16:00:00', 30, 'completed', 'Child wellness check', 'Annual checkup for 8-year-old son'),
('patient_006', 'doc_001', '2025-08-28 13:00:00', 30, 'completed', 'Blood pressure follow-up', 'Monitoring hypertension treatment'),
('patient_001', 'doc_005', '2025-09-08 15:30:00', 45, 'scheduled', 'Stress management', 'Work-related stress and sleep issues'),
('patient_002', 'doc_003', '2025-09-07 10:30:00', 30, 'scheduled', 'Prenatal consultation', 'First pregnancy, general questions');

-- Insert sample wellness insights
INSERT INTO wellness_insights (user_id, insight_type, value, recorded_date, notes) VALUES
('patient_001', 'activity', '8500', '2025-09-01', 'Morning jog and evening walk'),
('patient_001', 'mood', '7', '2025-09-01', 'Feeling good today, productive at work'),
('patient_001', 'sleep', '7.5', '2025-08-31', 'Slept well, woke up refreshed'),
('patient_001', 'nutrition', 'Good', '2025-09-01', 'Balanced meals, lots of vegetables'),
('patient_002', 'activity', '6200', '2025-09-01', 'Busy day at office, limited movement'),
('patient_002', 'mood', '6', '2025-09-01', 'Slightly stressed about upcoming presentation'),
('patient_002', 'sleep', '6', '2025-08-31', 'Had trouble falling asleep'),
('patient_003', 'activity', '4500', '2025-09-01', 'Knee pain limited walking today'),
('patient_003', 'mood', '5', '2025-09-01', 'Frustrated with ongoing knee issues'),
('patient_004', 'sleep', '8', '2025-09-01', 'New sleep routine is working well'),
('patient_004', 'mood', '8', '2025-09-01', 'Therapy session went really well'),
('patient_005', 'activity', '12000', '2025-09-01', 'Long bike ride with family'),
('patient_005', 'nutrition', 'Excellent', '2025-09-01', 'Meal prep Sunday paid off'),
('patient_006', 'activity', '7800', '2025-09-01', 'Yoga class and grocery shopping'),
('patient_006', 'mood', '9', '2025-09-01', 'Great day, feeling very positive');

-- Insert sample health resources
INSERT INTO health_resources (title, category, content, author, image_url, external_url, is_featured) VALUES
('Understanding Heart Health: Prevention and Early Detection', 'general', 'Cardiovascular disease remains the leading cause of death globally, but many heart conditions are preventable through lifestyle changes and early detection. This comprehensive guide covers risk factors, warning signs, and evidence-based prevention strategies including diet, exercise, and stress management techniques.', 'Dr. Sarah Johnson', 'https://images.unsplash.com/photo-1559757148-5c350d0d3c56?w=600', 'https://example.com/heart-health', TRUE),

('Mental Health in the Digital Age: Managing Stress and Anxiety', 'mental_health', 'Modern life presents unique challenges to mental wellness. Learn about recognizing anxiety symptoms, developing coping strategies, and when to seek professional help. This article includes practical techniques for mindfulness, breathing exercises, and creating healthy boundaries with technology.', 'Dr. Lisa Williams', 'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=600', 'https://example.com/mental-health', TRUE),

('Nutrition Fundamentals: Building a Sustainable Healthy Diet', 'nutrition', 'Discover the science behind optimal nutrition and learn how to create meal plans that support your health goals. This guide debunks common diet myths, explains macronutrients and micronutrients, and provides practical tips for grocery shopping and meal preparation.', 'Nutritionist Jane Adams', 'https://images.unsplash.com/photo-1490645935967-10de6ba17061?w=600', 'https://example.com/nutrition-guide', FALSE),

('Exercise for Beginners: Starting Your Fitness Journey Safely', 'exercise', 'Beginning an exercise routine can feel overwhelming, but it doesnt have to be. This beginner-friendly guide covers different types of exercise, how to set realistic goals, proper form techniques, and how to avoid common injuries. Includes sample workout routines for all fitness levels.', 'Personal Trainer Mike Stevens', 'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=600', 'https://example.com/exercise-basics', FALSE),

('Skin Cancer Prevention: Protecting Your Largest Organ', 'general', 'Skin cancer is one of the most common yet preventable forms of cancer. Learn about different types of skin cancer, how to perform self-examinations, the importance of sun protection, and when to see a dermatologist. Includes a guide to reading sunscreen labels and choosing protective clothing.', 'Dr. Michael Chen', 'https://images.unsplash.com/photo-1556228578-8c89e6adf883?w=600', 'https://example.com/skin-protection', FALSE),

('Sleep Hygiene: The Foundation of Good Health', 'general', 'Quality sleep is essential for physical and mental health, yet many people struggle with sleep issues. This comprehensive guide covers sleep cycles, common sleep disorders, and evidence-based strategies for improving sleep quality including bedroom environment, bedtime routines, and lifestyle factors.', 'Sleep Specialist Dr. Robert Park', 'https://images.unsplash.com/photo-1541781774459-bb2af2f05b55?w=600', 'https://example.com/sleep-health', TRUE),

('Managing Chronic Pain: A Holistic Approach', 'general', 'Chronic pain affects millions of people worldwide. This article explores various pain management strategies including physical therapy, medication options, alternative treatments, and psychological approaches. Learn how to work with healthcare providers to develop a comprehensive pain management plan.', 'Dr. David Thompson', 'https://images.unsplash.com/photo-1559757175-0eb30cd8c063?w=600', 'https://example.com/chronic-pain', FALSE),

('Mindful Eating: Developing a Healthy Relationship with Food', 'nutrition', 'Mindful eating is about paying attention to your food and eating experiences without judgment. This practice can help with weight management, reduce emotional eating, and increase meal satisfaction. Learn techniques for eating mindfully and recognizing hunger and fullness cues.', 'Dietitian Sarah Martinez', 'https://images.unsplash.com/photo-1547496502-affa22d3bacb?w=600', 'https://example.com/mindful-eating', FALSE);

-- Insert doctor availability (Monday = 0, Sunday = 6)
INSERT INTO doctor_availability (doctor_id, day_of_week, start_time, end_time, is_available) VALUES
-- Dr. Sarah Johnson (Cardiology)
('doc_001', 1, '09:00', '17:00', TRUE),
('doc_001', 2, '09:00', '17:00', TRUE),
('doc_001', 3, '09:00', '17:00', TRUE),
('doc_001', 4, '09:00', '15:00', TRUE),
('doc_001', 5, '09:00', '12:00', TRUE),

-- Dr. Michael Chen (Dermatology)
('doc_002', 1, '08:00', '16:00', TRUE),
('doc_002', 2, '08:00', '16:00', TRUE),
('doc_002', 3, '10:00', '18:00', TRUE),
('doc_002', 4, '08:00', '16:00', TRUE),
('doc_002', 5, '08:00', '14:00', TRUE),

-- Dr. Emily Rodriguez (Pediatrics)
('doc_003', 1, '08:00', '17:00', TRUE),
('doc_003', 2, '08:00', '17:00', TRUE),
('doc_003', 3, '08:00', '17:00', TRUE),
('doc_003', 4, '08:00', '17:00', TRUE),
('doc_003', 5, '08:00', '15:00', TRUE),
('doc_003', 6, '09:00', '13:00', TRUE),

-- Dr. David Thompson (Orthopedics)
('doc_004', 1, '07:00', '15:00', TRUE),
('doc_004', 2, '07:00', '15:00', TRUE),
('doc_004', 3, '07:00', '15:00', TRUE),
('doc_004', 4, '07:00', '15:00', TRUE),
('doc_004', 5, '07:00', '12:00', TRUE),

-- Dr. Lisa Williams (Mental Health)
('doc_005', 1, '10:00', '18:00', TRUE),
('doc_005', 2, '10:00', '18:00', TRUE),
('doc_005', 3, '10:00', '18:00', TRUE),
('doc_005', 4, '10:00', '18:00', TRUE),
('doc_005', 5, '10:00', '16:00', TRUE);
