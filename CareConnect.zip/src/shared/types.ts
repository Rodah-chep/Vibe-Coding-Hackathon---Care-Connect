import z from "zod";

// User Profile Types
export const UserProfileSchema = z.object({
  id: z.number(),
  user_id: z.string(),
  role: z.enum(['patient', 'doctor']),
  first_name: z.string().nullable(),
  last_name: z.string().nullable(),
  phone: z.string().nullable(),
  date_of_birth: z.string().nullable(),
  gender: z.string().nullable(),
  medical_license_number: z.string().nullable(),
  specialization: z.string().nullable(),
  bio: z.string().nullable(),
  years_experience: z.number().nullable(),
  hourly_rate: z.number().nullable(),
  profile_image_url: z.string().nullable(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const CreateUserProfileSchema = z.object({
  role: z.enum(['patient', 'doctor']),
  first_name: z.string().optional(),
  last_name: z.string().optional(),
  phone: z.string().optional(),
  date_of_birth: z.string().optional(),
  gender: z.string().optional(),
  medical_license_number: z.string().optional(),
  specialization: z.string().optional(),
  bio: z.string().optional(),
  years_experience: z.number().optional(),
  hourly_rate: z.number().optional(),
  profile_image_url: z.string().optional(),
});

// Appointment Types
export const AppointmentSchema = z.object({
  id: z.number(),
  patient_id: z.string(),
  doctor_id: z.string(),
  appointment_date: z.string(),
  duration_minutes: z.number(),
  status: z.enum(['scheduled', 'completed', 'cancelled']),
  reason: z.string().nullable(),
  notes: z.string().nullable(),
  video_call_url: z.string().nullable(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const CreateAppointmentSchema = z.object({
  doctor_id: z.string(),
  appointment_date: z.string(),
  duration_minutes: z.number().default(30),
  reason: z.string().optional(),
});

// Wellness Insight Types
export const WellnessInsightSchema = z.object({
  id: z.number(),
  user_id: z.string(),
  insight_type: z.enum(['activity', 'mood', 'sleep', 'nutrition']),
  value: z.string(),
  recorded_date: z.string(),
  notes: z.string().nullable(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const CreateWellnessInsightSchema = z.object({
  insight_type: z.enum(['activity', 'mood', 'sleep', 'nutrition']),
  value: z.string(),
  recorded_date: z.string(),
  notes: z.string().optional(),
});

// Health Resource Types
export const HealthResourceSchema = z.object({
  id: z.number(),
  title: z.string(),
  category: z.enum(['mental_health', 'nutrition', 'exercise', 'general']),
  content: z.string(),
  author: z.string().nullable(),
  image_url: z.string().nullable(),
  external_url: z.string().nullable(),
  is_featured: z.boolean(),
  created_at: z.string(),
  updated_at: z.string(),
});

// Doctor Availability Types
export const DoctorAvailabilitySchema = z.object({
  id: z.number(),
  doctor_id: z.string(),
  day_of_week: z.number().min(0).max(6),
  start_time: z.string(),
  end_time: z.string(),
  is_available: z.boolean(),
  created_at: z.string(),
  updated_at: z.string(),
});

// Inferred Types
export type UserProfile = z.infer<typeof UserProfileSchema>;
export type CreateUserProfile = z.infer<typeof CreateUserProfileSchema>;
export type Appointment = z.infer<typeof AppointmentSchema>;
export type CreateAppointment = z.infer<typeof CreateAppointmentSchema>;
export type WellnessInsight = z.infer<typeof WellnessInsightSchema>;
export type CreateWellnessInsight = z.infer<typeof CreateWellnessInsightSchema>;
export type HealthResource = z.infer<typeof HealthResourceSchema>;
export type DoctorAvailability = z.infer<typeof DoctorAvailabilitySchema>;
