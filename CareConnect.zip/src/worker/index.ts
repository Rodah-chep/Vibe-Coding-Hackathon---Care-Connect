import { Hono } from "hono";
import { cors } from "hono/cors";
import { zValidator } from "@hono/zod-validator";
import { getCookie, setCookie } from "hono/cookie";
import {
  exchangeCodeForSessionToken,
  getOAuthRedirectUrl,
  authMiddleware,
  deleteSession,
  MOCHA_SESSION_TOKEN_COOKIE_NAME,
} from "@getmocha/users-service/backend";
import {
  CreateUserProfileSchema,
  CreateAppointmentSchema,
  CreateWellnessInsightSchema,
} from "@/shared/types";

const app = new Hono<{ Bindings: Env }>();

app.use("/*", cors());

// Auth endpoints
app.get('/api/oauth/google/redirect_url', async (c) => {
  const redirectUrl = await getOAuthRedirectUrl('google', {
    apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
    apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
  });

  return c.json({ redirectUrl }, 200);
});

app.post("/api/sessions", async (c) => {
  const body = await c.req.json();

  if (!body.code) {
    return c.json({ error: "No authorization code provided" }, 400);
  }

  try {
    const sessionToken = await exchangeCodeForSessionToken(body.code, {
      apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
      apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
    });

    setCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME, sessionToken, {
      httpOnly: true,
      path: "/",
      sameSite: "none",
      secure: true,
      maxAge: 60 * 24 * 60 * 60, // 60 days
    });

    return c.json({ success: true }, 200);
  } catch (error) {
    return c.json({ error: "Failed to exchange code for session token" }, 400);
  }
});

app.get("/api/users/me", authMiddleware, async (c) => {
  return c.json(c.get("user"));
});

app.get('/api/logout', async (c) => {
  const sessionToken = getCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME);

  if (typeof sessionToken === 'string') {
    await deleteSession(sessionToken, {
      apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
      apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
    });
  }

  setCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME, '', {
    httpOnly: true,
    path: '/',
    sameSite: 'none',
    secure: true,
    maxAge: 0,
  });

  return c.json({ success: true }, 200);
});

// User Profile endpoints
app.get("/api/profiles/me", authMiddleware, async (c) => {
  const user = c.get("user")!;
  
  const { results } = await c.env.DB.prepare(
    "SELECT * FROM user_profiles WHERE user_id = ?"
  ).bind(user.id).all();

  return c.json(results[0] || null);
});

app.post("/api/profiles", authMiddleware, zValidator("json", CreateUserProfileSchema), async (c) => {
  const user = c.get("user")!;
  const profile = c.req.valid("json");

  const { success } = await c.env.DB.prepare(`
    INSERT INTO user_profiles (
      user_id, role, first_name, last_name, phone, date_of_birth, gender,
      medical_license_number, specialization, bio, years_experience, hourly_rate, profile_image_url
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).bind(
    user.id,
    profile.role,
    profile.first_name || null,
    profile.last_name || null,
    profile.phone || null,
    profile.date_of_birth || null,
    profile.gender || null,
    profile.medical_license_number || null,
    profile.specialization || null,
    profile.bio || null,
    profile.years_experience || null,
    profile.hourly_rate || null,
    profile.profile_image_url || null
  ).run();

  if (!success) {
    return c.json({ error: "Failed to create profile" }, 500);
  }

  return c.json({ success: true }, 201);
});

// Doctors endpoint
app.get("/api/doctors", async (c) => {
  const { results } = await c.env.DB.prepare(`
    SELECT * FROM user_profiles 
    WHERE role = 'doctor' 
    ORDER BY created_at DESC
  `).all();

  return c.json(results);
});

// Appointments endpoints
app.get("/api/appointments", authMiddleware, async (c) => {
  const user = c.get("user")!;
  
  const { results } = await c.env.DB.prepare(`
    SELECT a.*, 
           p.first_name as patient_first_name, p.last_name as patient_last_name,
           d.first_name as doctor_first_name, d.last_name as doctor_last_name,
           d.specialization
    FROM appointments a
    LEFT JOIN user_profiles p ON a.patient_id = p.user_id
    LEFT JOIN user_profiles d ON a.doctor_id = d.user_id
    WHERE a.patient_id = ? OR a.doctor_id = ?
    ORDER BY a.appointment_date ASC
  `).bind(user.id, user.id).all();

  return c.json(results);
});

app.post("/api/appointments", authMiddleware, zValidator("json", CreateAppointmentSchema), async (c) => {
  const user = c.get("user")!;
  const appointment = c.req.valid("json");

  const { success } = await c.env.DB.prepare(`
    INSERT INTO appointments (patient_id, doctor_id, appointment_date, duration_minutes, reason)
    VALUES (?, ?, ?, ?, ?)
  `).bind(
    user.id,
    appointment.doctor_id,
    appointment.appointment_date,
    appointment.duration_minutes,
    appointment.reason || null
  ).run();

  if (!success) {
    return c.json({ error: "Failed to create appointment" }, 500);
  }

  return c.json({ success: true }, 201);
});

// Wellness insights endpoints
app.get("/api/wellness", authMiddleware, async (c) => {
  const user = c.get("user")!;
  
  const { results } = await c.env.DB.prepare(`
    SELECT * FROM wellness_insights 
    WHERE user_id = ? 
    ORDER BY recorded_date DESC
  `).bind(user.id).all();

  return c.json(results);
});

app.post("/api/wellness", authMiddleware, zValidator("json", CreateWellnessInsightSchema), async (c) => {
  const user = c.get("user")!;
  const insight = c.req.valid("json");

  const { success } = await c.env.DB.prepare(`
    INSERT INTO wellness_insights (user_id, insight_type, value, recorded_date, notes)
    VALUES (?, ?, ?, ?, ?)
  `).bind(
    user.id,
    insight.insight_type,
    insight.value,
    insight.recorded_date,
    insight.notes || null
  ).run();

  if (!success) {
    return c.json({ error: "Failed to create wellness insight" }, 500);
  }

  return c.json({ success: true }, 201);
});

// Health resources endpoints
app.get("/api/resources", async (c) => {
  const category = c.req.query("category");
  
  let query = "SELECT * FROM health_resources ORDER BY is_featured DESC, created_at DESC";
  let params: any[] = [];
  
  if (category) {
    query = "SELECT * FROM health_resources WHERE category = ? ORDER BY is_featured DESC, created_at DESC";
    params = [category];
  }

  const { results } = await c.env.DB.prepare(query).bind(...params).all();

  return c.json(results);
});

export default app;
