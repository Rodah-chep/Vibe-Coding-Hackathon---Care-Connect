import { useState, useEffect } from "react";
import { useAuth } from "@getmocha/users-service/react";
import { useNavigate } from "react-router";
import { BookOpen, Search, ExternalLink, Heart, Activity, Brain, Utensils } from "lucide-react";
import Navbar from "@/react-app/components/Navbar";

interface HealthResource {
  id: number;
  title: string;
  category: 'mental_health' | 'nutrition' | 'exercise' | 'general';
  content: string;
  author?: string;
  image_url?: string;
  external_url?: string;
  is_featured: boolean;
  created_at: string;
}

const categories = [
  { value: '', label: 'All Categories', icon: BookOpen, color: 'gray' },
  { value: 'mental_health', label: 'Mental Health', icon: Brain, color: 'purple' },
  { value: 'nutrition', label: 'Nutrition', icon: Utensils, color: 'green' },
  { value: 'exercise', label: 'Exercise', icon: Activity, color: 'blue' },
  { value: 'general', label: 'General Health', icon: Heart, color: 'pink' },
];

export default function Resources() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [resources, setResources] = useState<HealthResource[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [expandedResource, setExpandedResource] = useState<number | null>(null);

  useEffect(() => {
    if (!user) {
      navigate("/");
      return;
    }

    const fetchResources = async () => {
      try {
        const url = selectedCategory 
          ? `/api/resources?category=${selectedCategory}`
          : '/api/resources';
        const response = await fetch(url);
        const data = await response.json();
        setResources(data);
      } catch (error) {
        console.error('Error fetching health resources:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchResources();
  }, [user, navigate, selectedCategory]);

  const filteredResources = resources.filter(resource =>
    resource.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    resource.content.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const featuredResources = filteredResources.filter(resource => resource.is_featured);
  const regularResources = filteredResources.filter(resource => !resource.is_featured);

  const getCategoryInfo = (category: string) => {
    return categories.find(c => c.value === category) || categories[0];
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const truncateContent = (content: string, maxLength: number = 200) => {
    if (content.length <= maxLength) return content;
    return content.substring(0, maxLength) + '...';
  };

  if (!user || loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <div className="flex items-center justify-center pt-20">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      {/* Hero Section with Background */}
      <div className="relative h-72 bg-cover bg-center" style={{
        backgroundImage: `url('https://mocha-cdn.com/0198f7b9-4f8d-7484-bfa7-e96a4703ce38/resources-background.jpg')`
      }}>
        <div className="absolute inset-0 bg-gradient-to-r from-purple-800/80 to-blue-800/70"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 text-center">
          <h1 className="text-4xl font-bold text-white mb-4">Health Resources</h1>
          <p className="text-purple-100 text-lg">Discover articles, tips, and guides for better health and wellness</p>
        </div>
      </div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        

        {/* Search and Filters */}
        <div className="bg-white rounded-2xl shadow-lg p-6 mb-8">
          <div className="flex flex-col lg:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
              <input
                type="text"
                placeholder="Search health resources..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            
            <div className="lg:w-64">
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                {categories.map(category => (
                  <option key={category.value} value={category.value}>
                    {category.label}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Featured Resources */}
        {featuredResources.length > 0 && (
          <div className="mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Featured Resources</h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {featuredResources.map((resource) => {
                const categoryInfo = getCategoryInfo(resource.category);
                const Icon = categoryInfo.icon;
                const isExpanded = expandedResource === resource.id;
                
                return (
                  <div key={resource.id} className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-200">
                    {resource.image_url && (
                      <div className="h-48 bg-gradient-to-r from-blue-500 to-teal-500"></div>
                    )}
                    
                    <div className="p-6">
                      <div className="flex items-center space-x-2 mb-3">
                        <div className={`p-2 rounded-lg bg-${categoryInfo.color}-100`}>
                          <Icon className={`h-4 w-4 text-${categoryInfo.color}-600`} />
                        </div>
                        <span className={`text-sm font-medium text-${categoryInfo.color}-600`}>
                          {categoryInfo.label}
                        </span>
                      </div>
                      
                      <h3 className="text-xl font-bold text-gray-900 mb-3">{resource.title}</h3>
                      
                      <p className="text-gray-600 mb-4">
                        {isExpanded ? resource.content : truncateContent(resource.content)}
                      </p>
                      
                      <div className="flex items-center justify-between">
                        <div className="text-sm text-gray-500">
                          {resource.author && <span>By {resource.author} • </span>}
                          {formatDate(resource.created_at)}
                        </div>
                        
                        <div className="flex space-x-2">
                          <button
                            onClick={() => setExpandedResource(isExpanded ? null : resource.id)}
                            className="text-blue-600 hover:text-blue-700 text-sm font-medium"
                          >
                            {isExpanded ? 'Show Less' : 'Read More'}
                          </button>
                          
                          {resource.external_url && (
                            <a
                              href={resource.external_url}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-blue-600 hover:text-blue-700 flex items-center space-x-1"
                            >
                              <ExternalLink className="h-4 w-4" />
                            </a>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Regular Resources */}
        <div>
          <h2 className="text-2xl font-bold text-gray-900 mb-6">
            {featuredResources.length > 0 ? 'More Resources' : 'All Resources'}
          </h2>
          
          {regularResources.length > 0 ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {regularResources.map((resource) => {
                const categoryInfo = getCategoryInfo(resource.category);
                const Icon = categoryInfo.icon;
                const isExpanded = expandedResource === resource.id;
                
                return (
                  <div key={resource.id} className="bg-white rounded-2xl shadow-lg p-6 hover:shadow-xl transition-shadow duration-200">
                    <div className="flex items-center space-x-2 mb-3">
                      <div className={`p-2 rounded-lg bg-${categoryInfo.color}-100`}>
                        <Icon className={`h-4 w-4 text-${categoryInfo.color}-600`} />
                      </div>
                      <span className={`text-sm font-medium text-${categoryInfo.color}-600`}>
                        {categoryInfo.label}
                      </span>
                    </div>
                    
                    <h3 className="text-lg font-bold text-gray-900 mb-3">{resource.title}</h3>
                    
                    <p className="text-gray-600 mb-4">
                      {isExpanded ? resource.content : truncateContent(resource.content)}
                    </p>
                    
                    <div className="flex items-center justify-between">
                      <div className="text-sm text-gray-500">
                        {resource.author && <span>By {resource.author} • </span>}
                        {formatDate(resource.created_at)}
                      </div>
                      
                      <div className="flex space-x-2">
                        <button
                          onClick={() => setExpandedResource(isExpanded ? null : resource.id)}
                          className="text-blue-600 hover:text-blue-700 text-sm font-medium"
                        >
                          {isExpanded ? 'Show Less' : 'Read More'}
                        </button>
                        
                        {resource.external_url && (
                          <a
                            href={resource.external_url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-blue-600 hover:text-blue-700 flex items-center space-x-1"
                          >
                            <ExternalLink className="h-4 w-4" />
                          </a>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="text-center py-12">
              <BookOpen className="h-16 w-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No resources found</h3>
              <p className="text-gray-600">
                {searchTerm || selectedCategory 
                  ? 'Try adjusting your search criteria' 
                  : 'Health resources will appear here when available'
                }
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
