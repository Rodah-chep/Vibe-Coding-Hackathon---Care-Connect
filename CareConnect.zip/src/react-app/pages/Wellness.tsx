import { useState, useEffect } from "react";
import { useAuth } from "@getmocha/users-service/react";
import { useNavigate } from "react-router";
import { Activity, Heart, Moon, Apple, Plus, TrendingUp, Calendar } from "lucide-react";
import Navbar from "@/react-app/components/Navbar";

interface WellnessInsight {
  id: number;
  insight_type: 'activity' | 'mood' | 'sleep' | 'nutrition';
  value: string;
  recorded_date: string;
  notes?: string;
  created_at: string;
}

const insightTypes = [
  { type: 'activity', label: 'Physical Activity', icon: Activity, color: 'blue' },
  { type: 'mood', label: 'Mood', icon: Heart, color: 'pink' },
  { type: 'sleep', label: 'Sleep', icon: Moon, color: 'purple' },
  { type: 'nutrition', label: 'Nutrition', icon: Apple, color: 'green' },
] as const;

export default function Wellness() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [insights, setInsights] = useState<WellnessInsight[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    insight_type: 'activity' as const,
    value: '',
    recorded_date: new Date().toISOString().split('T')[0],
    notes: '',
  });

  useEffect(() => {
    if (!user) {
      navigate("/");
      return;
    }

    const fetchInsights = async () => {
      try {
        const response = await fetch('/api/wellness');
        const data = await response.json();
        setInsights(data);
      } catch (error) {
        console.error('Error fetching wellness insights:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchInsights();
  }, [user, navigate]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);

    try {
      const response = await fetch('/api/wellness', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        // Refresh insights
        const updatedResponse = await fetch('/api/wellness');
        const updatedData = await updatedResponse.json();
        setInsights(updatedData);
        
        setShowForm(false);
        setFormData({
          insight_type: 'activity',
          value: '',
          recorded_date: new Date().toISOString().split('T')[0],
          notes: '',
        });
      } else {
        throw new Error('Failed to add insight');
      }
    } catch (error) {
      console.error('Error adding insight:', error);
      alert('Failed to add wellness insight. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  const getInsightIcon = (type: string) => {
    const insight = insightTypes.find(t => t.type === type);
    return insight ? insight.icon : Activity;
  };

  const getInsightColor = (type: string) => {
    const insight = insightTypes.find(t => t.type === type);
    return insight?.color || 'blue';
  };

  const getColorClasses = (color: string) => {
    const colors = {
      blue: 'bg-blue-100 text-blue-700 border-blue-200',
      pink: 'bg-pink-100 text-pink-700 border-pink-200',
      purple: 'bg-purple-100 text-purple-700 border-purple-200',
      green: 'bg-green-100 text-green-700 border-green-200',
    };
    return colors[color as keyof typeof colors] || colors.blue;
  };

  const groupedInsights = insights.reduce((acc, insight) => {
    if (!acc[insight.insight_type]) {
      acc[insight.insight_type] = [];
    }
    acc[insight.insight_type].push(insight);
    return acc;
  }, {} as Record<string, WellnessInsight[]>);

  if (!user || loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <div className="flex items-center justify-center pt-20">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      {/* Hero Section with Background */}
      <div className="relative h-72 bg-cover bg-center" style={{
        backgroundImage: `url('https://mocha-cdn.com/0198f7b9-4f8d-7484-bfa7-e96a4703ce38/wellness-background.jpg')`
      }}>
        <div className="absolute inset-0 bg-gradient-to-r from-teal-700/80 to-green-700/70"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 text-center">
          <h1 className="text-4xl font-bold text-white mb-4">Wellness Dashboard</h1>
          <p className="text-teal-100 text-lg">Track your health metrics and wellness journey</p>
        </div>
      </div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
          </div>
          <button
            onClick={() => setShowForm(true)}
            className="bg-gradient-to-r from-blue-500 to-teal-500 text-white px-6 py-3 rounded-lg hover:from-blue-600 hover:to-teal-600 transition-all duration-200 flex items-center space-x-2 shadow-lg"
          >
            <Plus className="h-5 w-5" />
            <span>Add Entry</span>
          </button>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          {insightTypes.map(({ type, label, icon: Icon, color }) => {
            const typeInsights = groupedInsights[type] || [];
            const recentCount = typeInsights.filter(insight => 
              new Date(insight.recorded_date) >= new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
            ).length;

            return (
              <div key={type} className="bg-white rounded-2xl shadow-lg p-6">
                <div className="flex items-center space-x-3 mb-4">
                  <div className={`p-2 rounded-full ${getColorClasses(color)}`}>
                    <Icon className="h-6 w-6" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">{label}</h3>
                    <p className="text-sm text-gray-600">{typeInsights.length} total entries</p>
                  </div>
                </div>
                <div className="flex items-center space-x-2 text-sm text-gray-600">
                  <TrendingUp className="h-4 w-4" />
                  <span>{recentCount} this week</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Recent Insights */}
        <div className="bg-white rounded-2xl shadow-lg p-6 mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Recent Insights</h2>
          
          {insights.length > 0 ? (
            <div className="space-y-4">
              {insights.slice(0, 10).map((insight) => {
                const Icon = getInsightIcon(insight.insight_type);
                const color = getInsightColor(insight.insight_type);
                const insightType = insightTypes.find(t => t.type === insight.insight_type);
                
                return (
                  <div key={insight.id} className="border border-gray-200 rounded-xl p-4 hover:shadow-md transition-shadow">
                    <div className="flex items-start space-x-4">
                      <div className={`p-2 rounded-full ${getColorClasses(color)} flex-shrink-0`}>
                        <Icon className="h-5 w-5" />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-2">
                          <h3 className="font-semibold text-gray-900">{insightType?.label}</h3>
                          <div className="flex items-center space-x-2 text-sm text-gray-500">
                            <Calendar className="h-4 w-4" />
                            <span>{new Date(insight.recorded_date).toLocaleDateString()}</span>
                          </div>
                        </div>
                        <p className="text-gray-700 mb-2">{insight.value}</p>
                        {insight.notes && (
                          <p className="text-sm text-gray-600">{insight.notes}</p>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="text-center py-12">
              <Activity className="h-16 w-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No wellness data yet</h3>
              <p className="text-gray-600 mb-4">Start tracking your wellness journey by adding your first entry</p>
              <button
                onClick={() => setShowForm(true)}
                className="bg-blue-500 text-white px-6 py-2 rounded-lg hover:bg-blue-600 transition-colors"
              >
                Add First Entry
              </button>
            </div>
          )}
        </div>

        {/* Add Entry Modal */}
        {showForm && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-2xl shadow-xl max-w-md w-full p-6">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Add Wellness Entry</h2>
              
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Type</label>
                  <select
                    value={formData.insight_type}
                    onChange={(e) => setFormData({...formData, insight_type: e.target.value as any})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    {insightTypes.map(({ type, label }) => (
                      <option key={type} value={type}>{label}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Value</label>
                  <input
                    type="text"
                    value={formData.value}
                    onChange={(e) => setFormData({...formData, value: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="e.g., 30 minutes walking, 8 hours sleep, felt energetic"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Date</label>
                  <input
                    type="date"
                    value={formData.recorded_date}
                    onChange={(e) => setFormData({...formData, recorded_date: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Notes (Optional)</label>
                  <textarea
                    value={formData.notes}
                    onChange={(e) => setFormData({...formData, notes: e.target.value})}
                    rows={3}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="Additional details or observations..."
                  />
                </div>

                <div className="flex space-x-3 pt-4">
                  <button
                    type="button"
                    onClick={() => setShowForm(false)}
                    className="flex-1 px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={submitting}
                    className="flex-1 bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {submitting ? 'Adding...' : 'Add Entry'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
