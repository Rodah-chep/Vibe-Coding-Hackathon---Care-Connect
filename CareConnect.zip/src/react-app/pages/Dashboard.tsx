import { useState, useEffect } from "react";
import { useAuth } from "@getmocha/users-service/react";
import { useNavigate, Link } from "react-router";
import { Calendar, Clock, User, Activity, BookOpen, Plus } from "lucide-react";
import Navbar from "@/react-app/components/Navbar";

interface UserProfile {
  id: number;
  role: string;
  first_name: string;
  last_name: string;
}

interface Appointment {
  id: number;
  appointment_date: string;
  status: string;
  reason: string;
  doctor_first_name: string;
  doctor_last_name: string;
  patient_first_name: string;
  patient_last_name: string;
  specialization: string;
}

export default function Dashboard() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) {
      navigate("/");
      return;
    }

    const fetchData = async () => {
      try {
        // Fetch user profile
        const profileRes = await fetch('/api/profiles/me');
        const profileData = await profileRes.json();
        
        if (!profileData) {
          navigate("/profile/setup");
          return;
        }
        
        setProfile(profileData);

        // Fetch appointments
        const appointmentsRes = await fetch('/api/appointments');
        const appointmentsData = await appointmentsRes.json();
        setAppointments(appointmentsData);
        
      } catch (error) {
        console.error('Error fetching dashboard data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [user, navigate]);

  if (!user || loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <div className="flex items-center justify-center pt-20">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
        </div>
      </div>
    );
  }

  if (!profile) return null;

  const upcomingAppointments = appointments
    .filter(apt => apt.status === 'scheduled' && new Date(apt.appointment_date) > new Date())
    .sort((a, b) => new Date(a.appointment_date).getTime() - new Date(b.appointment_date).getTime())
    .slice(0, 3);

  const formatDateTime = (dateString: string) => {
    const date = new Date(dateString);
    return {
      date: date.toLocaleDateString(),
      time: date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      {/* Background Image Section */}
      <div className="relative h-64 bg-cover bg-center" style={{
        backgroundImage: `url('https://mocha-cdn.com/0198f7b9-4f8d-7484-bfa7-e96a4703ce38/dashboard-background.jpg')`
      }}>
        <div className="absolute inset-0 bg-gradient-to-r from-blue-600/70 to-teal-600/60"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 text-center">
          <h1 className="text-4xl font-bold text-white mb-2">
            Welcome back, {profile.first_name || user.email}!
          </h1>
          <p className="text-blue-100 text-lg">
            {profile.role === 'patient' ? 'Manage your health journey' : 'Manage your practice'}
          </p>
        </div>
      </div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Quick Actions */}

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Link 
            to="/doctors" 
            className="bg-gradient-to-r from-blue-500 to-blue-600 text-white p-6 rounded-2xl hover:from-blue-600 hover:to-blue-700 transition-all duration-200 shadow-lg hover:shadow-xl transform hover:-translate-y-1"
          >
            <User className="h-8 w-8 mb-3" />
            <h3 className="font-semibold text-lg">Find Doctors</h3>
            <p className="text-blue-100 text-sm">Browse available specialists</p>
          </Link>
          
          <Link 
            to="/wellness" 
            className="bg-gradient-to-r from-teal-500 to-teal-600 text-white p-6 rounded-2xl hover:from-teal-600 hover:to-teal-700 transition-all duration-200 shadow-lg hover:shadow-xl transform hover:-translate-y-1"
          >
            <Activity className="h-8 w-8 mb-3" />
            <h3 className="font-semibold text-lg">Wellness</h3>
            <p className="text-teal-100 text-sm">Track your health metrics</p>
          </Link>
          
          <Link 
            to="/resources" 
            className="bg-gradient-to-r from-purple-500 to-purple-600 text-white p-6 rounded-2xl hover:from-purple-600 hover:to-purple-700 transition-all duration-200 shadow-lg hover:shadow-xl transform hover:-translate-y-1"
          >
            <BookOpen className="h-8 w-8 mb-3" />
            <h3 className="font-semibold text-lg">Resources</h3>
            <p className="text-purple-100 text-sm">Health tips and articles</p>
          </Link>
          
          <div className="bg-gradient-to-r from-green-500 to-green-600 text-white p-6 rounded-2xl">
            <Calendar className="h-8 w-8 mb-3" />
            <h3 className="font-semibold text-lg">{appointments.length}</h3>
            <p className="text-green-100 text-sm">Total Appointments</p>
          </div>
        </div>

        {/* Upcoming Appointments */}
        <div className="bg-white rounded-2xl shadow-lg p-6 mb-8">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-gray-900">Upcoming Appointments</h2>
            <Link 
              to="/doctors" 
              className="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition-colors flex items-center space-x-2"
            >
              <Plus className="h-4 w-4" />
              <span>Book New</span>
            </Link>
          </div>
          
          {upcomingAppointments.length > 0 ? (
            <div className="space-y-4">
              {upcomingAppointments.map((appointment) => {
                const { date, time } = formatDateTime(appointment.appointment_date);
                const doctorName = profile.role === 'patient' 
                  ? `Dr. ${appointment.doctor_first_name} ${appointment.doctor_last_name}`
                  : `${appointment.patient_first_name} ${appointment.patient_last_name}`;
                
                return (
                  <div key={appointment.id} className="border border-gray-200 rounded-xl p-4 hover:shadow-md transition-shadow">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        <div className="bg-blue-100 p-3 rounded-full">
                          <Calendar className="h-6 w-6 text-blue-600" />
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-900">{doctorName}</h3>
                          {appointment.specialization && (
                            <p className="text-sm text-gray-600">{appointment.specialization}</p>
                          )}
                          {appointment.reason && (
                            <p className="text-sm text-gray-500">Reason: {appointment.reason}</p>
                          )}
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="flex items-center space-x-2 text-gray-600">
                          <Calendar className="h-4 w-4" />
                          <span className="text-sm">{date}</span>
                        </div>
                        <div className="flex items-center space-x-2 text-gray-600 mt-1">
                          <Clock className="h-4 w-4" />
                          <span className="text-sm">{time}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="text-center py-8">
              <Calendar className="h-16 w-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No upcoming appointments</h3>
              <p className="text-gray-600 mb-4">Schedule your first appointment to get started</p>
              <Link 
                to="/doctors" 
                className="bg-blue-500 text-white px-6 py-2 rounded-lg hover:bg-blue-600 transition-colors"
              >
                Find a Doctor
              </Link>
            </div>
          )}
        </div>

        {/* Health Tips */}
        <div className="bg-gradient-to-r from-blue-50 to-teal-50 rounded-2xl p-6 border border-blue-100">
          <h2 className="text-xl font-bold text-gray-900 mb-4">Today's Health Tip</h2>
          <div className="flex items-start space-x-4">
            <div className="bg-blue-500 p-2 rounded-full flex-shrink-0">
              <Activity className="h-6 w-6 text-white" />
            </div>
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">Stay Hydrated</h3>
              <p className="text-gray-700">
                Drinking adequate water throughout the day helps maintain your body's fluid balance, 
                supports digestion, and keeps your skin healthy. Aim for 8 glasses of water daily.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
